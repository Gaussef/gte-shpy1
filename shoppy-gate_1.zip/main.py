from rich.console import Console
from index import main
import os, sys, time
from rich import print

def start():
    try:
        with open("cc.txt", "r") as fl:
            tarjetas = fl.readlines()
    except FileNotFoundError:
        print("Intenta de nuevo, saliendo en 2 segundos.")
        time.sleep(2)
        sys.exit()
    restantes = []
    for tarjeta in tarjetas:
        tarjeta = tarjeta.strip()
        try:
            time.sleep(3)
            print(main(tarjeta)) 
        except Exception as e:
            print(f"Error con tarjeta {tarjeta}: {e}")
            restantes.append(tarjeta)
    with open("cc.txt", "w") as fl:
        for r in restantes:
            fl.write(r + "\n")

def save():
    print("Pega tu material aquí:\n")
   
    lines = []
    while True:
        try:
            line = input()
            if line == "":
                break  
            lines.append(line)
        except EOFError:
            break

    with open("cc.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print("[green][INFO] Guardado en cc.txt")
    

def saludo():
    console = Console()
    logo = r"""
░▒▓███████▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░░▒▓███████▓▒░░▒▓███████▓▒░       
░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      
░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      
 ░▒▓██████▓▒░░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░░▒▓███████▓▒░       
       ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░             
       ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░             
░▒▓███████▓▒░░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓█▓▒░             
"""
    console.print(logo, style="bold red")
    print("============= SCRIPT BY APFRS5 =============")
if __name__ == "__main__":
    try:
        os.system("clear")
        saludo()
        des = input("Guardamos material??? s/n: ")
        if des == "s":
            save()
            des2 = input('Comenzamos?? s/n: ')
            if des2 == "s":
                os.system("clear")
                saludo()
                start()
            else:
                time.sleep(10)
                print("Cerrando en 10 segundos...")
                sys.exit()
        else:
            os.system("clear")
            saludo()
            start()
    except:
        sys.exit()